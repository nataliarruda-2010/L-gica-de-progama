
package ex02_conversão_firenheit_celsius;

import java.util.Scanner;

public class Ex02_conversão_firenheit_celsius {

    
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        double F, C;
        System.out.println("Digite os graus em Firenheit:");
        F = teclado.nextDouble();
        C = (F-32)*5/9;
        System.out.println("A temperatura em Celsius é: " + C);
    }
    
}
