
package ex03_volume_lata_de_oleo;

import java.util.Scanner;

public class Ex03_Volume_Lata_de_Oleo {

    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double VOLUME, RAIO, ALTURA;
        
        System.out.println("Digite o Raio");
        RAIO = teclado.nextDouble();
        System.out.println("Digite a Altura");
        ALTURA = teclado.nextDouble();
        VOLUME = 3.14159*RAIO*RAIO*ALTURA;
        System.out.println("O volume da lata de óleo é: "+ VOLUME);
    }
    
}
