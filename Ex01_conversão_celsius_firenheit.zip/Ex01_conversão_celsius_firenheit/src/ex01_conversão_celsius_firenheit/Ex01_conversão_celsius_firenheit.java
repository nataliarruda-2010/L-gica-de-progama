
package ex01_conversão_celsius_firenheit;

import java.util.Scanner;

public class Ex01_conversão_celsius_firenheit {

    
    public static void main(String[] args) {
        Scanner teclado = new Scanner (System.in);
        double C,F;
        System.out.println("Digite os graus Celsius");
        C = teclado.nextDouble();
        F = ((9*C + 160)/5);
        System.out.println("A temperatura em Firenheit é "+ F);
    }
    
}
