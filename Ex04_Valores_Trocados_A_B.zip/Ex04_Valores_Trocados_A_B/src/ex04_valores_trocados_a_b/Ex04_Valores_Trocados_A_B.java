package ex04_valores_trocados_a_b;

import java.util.Scanner;

public class Ex04_Valores_Trocados_A_B {
/*SA = Salva o A no armazenamento*/
    public static void main(String[] args) {
        Scanner teclado = new Scanner(System.in);
        double A, B, SA;
        
        System.out.println("Digite o Valor de A");
        A = teclado.nextDouble();
        System.out.println("Digite o valor de B");
        B = teclado.nextDouble();
        SA = B;
        B = A;
        A = SA;
        System.out.println("Agora A é "+A);
        System.out.println("Agora B é: "+B);
    }

}
